CCD - Node API

### Node.js / Express / MongoDB (Mongoose) starter kit

- [Node.js](https://nodejs.org/en/)
- [MongoDB](https://www.mongodb.com/)
- [Mongoose](http://mongoosejs.com/index.html)
- [JSON Web Token](https://jwt.io/)

**Testing**

- [Mocha](https://mochajs.org/)
- [Chai](http://chaijs.com/)
- [Supertest](https://github.com/visionmedia/supertest)

Clone the repo and run the app

```
npm i
npm run start

```
