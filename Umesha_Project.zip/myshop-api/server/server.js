const express = require('express');
const app = express();
import attachMiddlewares from './middlewares/index';
var path = require('path');
var swaggerUi = require('swagger-ui-express'),
  swaggerDocument = require('./swagger.json');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
// app.use('/api/v1', router);
// Load config files
attachMiddlewares(app);
var dir = path.join(__dirname, 'uploads');
app.use(express.static(dir));

process
  .on('unhandledRejection', (reason, p) => {
    console.error(reason, 'Unhandled Rejection at Promise', p);
  })
  .on('uncaughtException', err => {
    console.error(
      new Date().toUTCString() + ' uncaughtException:',
      err.message
    );
    console.error(err.stack);
    process.exit(1);
  });

module.exports = app;