const Router = require("express").Router();
const controller = require("./controller");

// Get all templates
Router.route("/top/viewed")
	.get(controller.getMostViewedProducts);
Router.route("/").get(controller.getAllProducts)
	.post(controller.addProduct);
Router.route("/:id")
	.get(controller.getOneProducts)
	.delete(controller.deleteOneProduct);


module.exports = Router;
