const axios = require('axios');

const products = require('./model')
const constants = require('../utils/CONSTATNS');
module.exports = {
    getAllProducts,
    getOneProducts,
    deleteOneProduct,
    addProduct,
    getMostViewedProducts
};


async function getMostViewedProducts(req, res) {
    let limitCount = 5;
    let currencyCode = req.query.currency;
    if (req.query.limit != undefined) {
        limitCount = parseInt(req.query.limit);
    }

    if (currencyCode != undefined) {
        currencyCode = currencyCode;
    } else {
        currencyCode = 'USD';
    }

    let currency = await getCurrency();
    try {
        let mostviewed = await products.find({ "product_enable": true, "viewcount": { $gte: 10 } })
            .sort({ "viewcount": -1 }).limit(limitCount);
        res.status(200).send({
            msg: 'Top viewed products',
            result: (mostviewed.map((value) => ({
                currency: currencyCode,
                product_enable: value.product_enable,
                _id: value._id,
                viewcount: value.viewcount,
                title: value.title,
                price: value.price,
                description: value.category,
                category: value.category,
                image: value.image,
                price: (value.price * currency.data.rates[currencyCode]).toFixed(2)
            })))
        });
    } catch (err) {
        res.status(500).send({ msg: constants.INTERNAL_SERVER_ERROR, err: err })
    }
}

async function addProduct(req, res) {
    let productPayload = req.body;
    // productPayload.product_enable = true;
    let productSave = new products(productPayload);
    try {
        let response = await productSave.save();
        res.status(200).send({ msg: 'Product added sucessfully', result: response });
    } catch (err) {
        res.status(500).json({ msg: constants.INTERNAL_SERVER_ERROR, err: err });
    }
}

function deleteOneProduct(req, res) {
    let id = req.params.id;
    if (id != undefined || id != null || id != '') {
        products.findByIdAndUpdate(
            { _id: req.params.id },
            { $set: { product_enable: false, updatedby: 'system', updatedOn: new Date() } },
            { multi: false }, function (err, response) {
                if (!err) {
                    res.status(200).send({ msg: 'Deleted', result: response });
                } else {
                    res.status(500).send({ msg: 'error while deletion', result: response });
                }
            });
    } else {
        res.send({ msg: 'Id should mandatory to process' });
    }
}

// This method example for async await
async function getAllProducts(req, res) {
    try {
        const resultSet = await products.find({ product_enable: true });
        res.status(200).send({ msg: 'Sucess', result: resultSet });
    } catch (err) {
        res.status(500).send({ msg: constants.INTERNAL_SERVER_ERROR, error: err })
    }
}

// This method example for callback
function getOneProducts(req, res) {
    let id = req.params.id;
    let currency = req.query.currency;
    let url = 'https://api.exchangeratesapi.io/latest?base=USD';
    axios.get(url)
        .then(function (response) {
            products.findOneAndUpdate({ _id: id, product_enable: true }, {
                $inc: {
                    viewcount: 1
                }
            }, { new: true }, function (err, resultSet) {
                if (resultSet == null) {
                    res.status(200).send({ msg: 'Sucess', result: 'Document not found' });
                } else {
                    if (!err) {
                        let resultSet1 = resultSet;
                        resultSet1['price'] = (resultSet.price * response.data.rates[currency]).toFixed(2);
                        resultSet1[currency] = currency;
                        res.status(200).send({ msg: 'Sucess', result: resultSet });
                    } else {
                        res.status(500).send({ msg: constants.INTERNAL_SERVER_ERROR, error: err })
                    }
                }
            });
        })
        .catch(function (error) {
            res.status(500).send({ msg: constants.INTERNAL_SERVER_ERROR, error: error.response.data })
        })
}

async function getCurrency() {
    try {
        let url = 'https://api.exchangeratesapi.io/latest?base=USD';
        const response = await axios.get(url);
        // console.log(response);
        return response;
    } catch (error) {
        // console.error(error);
        return error;
    }
}