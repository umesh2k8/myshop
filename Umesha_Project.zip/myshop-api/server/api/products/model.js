const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const products = new Schema({
    title: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true,
        index: false
    },
    description: {
        type: String,
        required: true,
        index: false
    },
    category: {
        type: String,
        required: true,
        index: true
    },
    image: {
        type: String,
        required: true
    },
    viewcount: {
        type: Number,
        required: true,
        index: true
    },
    createdOn: {
        type: Date,
        required: false
    },
    updatedOn: {
        type: Date,
        required: false
    },
    createdby: {
        type: String,
        required: false
    },
    updatedby: {
        type: String,
        required: false
    },
    product_enable: {
        type: Boolean,
        default: true
    }
});
module.exports = mongoose.model('productdetails', products);
