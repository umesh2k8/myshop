module.exports = Object.freeze({
    INTERNAL_SERVER_ERROR: 'Internal Server Error',
    SUCESS_MESSAGE: 'Processd sucessfully'
});
