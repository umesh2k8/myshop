const app = require('./server');
const config = require('./config/config');
const mongoose = require('mongoose');

// console.log("==>Connected Database URL: " + config.db.url);


mongoose
  .connect(config.db.url, {
    useNewUrlParser: true,
    // sets how many times to try reconnecting
    reconnectTries: Number.MAX_VALUE,
    // sets the delay between every retry (milliseconds)
    reconnectInterval: 1000
  })
  .then(
    () => {
      /** ready to use. The `mongoose.connect()` promise resolves to undefined. */
      console.log(`Connected Database URL: ${config.db.name}`);
    },
    err => {
      /** handle initial connection error */
      console.log("err while...");
      console.log(err);
    }
  );
mongoose.set('useCreateIndex', true);
mongoose.set('debug', false);

app.listen(process.env.PORT || config.port, () => {
  console.log(`Connected to http://localhost:${config.port}`);
});
