// This module is only used to attach middlewares to the express app
import errorHandler from './errorHandler';
import bodyParser from 'body-parser';
const api = require('../api/api');
import compression from 'compression';
import morgan from 'morgan';
import helmet from 'helmet';
import cors from 'cors';

module.exports = function attachMiddlewares(app) {
  app.use(morgan('dev'));
  app.use(compression());
  app.use(bodyParser.json({ limit: '1024mb', extended: true }));
  app.use(bodyParser.urlencoded({ limit: '1024mb', extended: true }));
  app.use(helmet());
  app.use(cors());
  // setup the api
  app.use('/api', api);
  app.use(errorHandler);
};
