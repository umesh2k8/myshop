// The error handler middleware that handles all errors
// and respond to the client
import logger from '../libs/logger';
import { map, omit } from 'lodash';

module.exports = function errorHandler(err, req, res, next) {
  // eslint-disable-line no-unused-vars
  // In case of a CustomError class, use it's data
  // Otherwise try to identify the type of error (mongoose validation, mongodb unique, ...)
  // If we can't identify it, respond with a generic 500 error
  let responseErr = err;
  // log the error
  logger.error(err, {
    method: req.method,
    originalUrl: req.originalUrl,

    // don't send sensitive information that only adds noise
    headers: omit(req.headers, [
      'x-api-key',
      'cookie',
      'password',
      'confirmPassword'
    ]),
    body: omit(req.body, ['password', 'confirmPassword']),

    httpCode: responseErr.httpCode,
    isHandledError: responseErr.httpCode < 500
  });

  let jsonRes = {
    success: false,
    error: 'Internal server error',
    message: responseErr.name + ' ' + responseErr.message
  };

  if (responseErr.errors) {
    jsonRes.errors = responseErr.errors;
  }

  // In some occasions like when invalid JSON is supplied `res.respond` might be not yet avalaible,
  // in this case we use the standard res.status(...).json(...)
  return res.status(responseErr.httpCode || 500).json(jsonRes);
};
