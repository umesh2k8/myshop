module.exports = {
  db: {
    name: 'mongodb://localhost:27017/myshop?&authSource=admin',
    url:
      'mongodb+srv://umesh2k8:umesh2k8\@umesh_@cluster0.m1cva.mongodb.net/myshop?retryWrites=true&w=majority'
	  //local mongodb://localhost:27017/myshop?&authSource=admin
  }
};
