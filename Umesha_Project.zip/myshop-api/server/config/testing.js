module.exports = {
  db: {
    name: "mongodb://localhost:27017/myshop?&authSource=admin",
    url:
      'mongodb://localhost:27017/myshop?&authSource=admin'
  }
};